//
//  productnameTableViewCell.swift
//  kattabattula_ElectronicStore
//
//  Created by student on 4/26/22.
//

import UIKit

class productnameTableViewCell: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    @IBOutlet weak var prodNameLBL: UILabel!
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
