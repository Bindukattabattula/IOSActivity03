//
//  ViewController.swift
//  kattabattula_ElectronicStore
//
//  Created by student on 4/26/22.
//

import UIKit

class ElectronicViewController: UIViewController,UITableViewDataSource,UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        Electronic.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        let Product = Electronic[indexPath.row]
        if let Cell = cell as? productnameTableViewCell{
            Cell.prodNameLBL.text = Product[0]
        }
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        self.performSegue(withIdentifier: "Detalproduct", sender: indexPath)
    }
    

    override func viewDidLoad() {
        super.viewDidLoad()
        productTable.dataSource = self
        productTable.delegate = self
        productTable.reloadData()
        // Do any additional setup after loading the view.
    }

    @IBOutlet weak var productTable: UITableView!
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if let identifier = segue.identifier{
            switch identifier{
            case "Detalproduct":
                if let destinationVC = segue.destination as? DetailViewController {
                    if let ip = sender as? IndexPath{
                        destinationVC.name = Electronic[ip.row][0]
                        destinationVC.price = Electronic[ip.row][1]
                    }
                }
            default: break
            }
        }
    }
    
}

