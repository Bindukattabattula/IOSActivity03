//
//  DetailViewController.swift
//  kattabattula_ElectronicStore
//
//  Created by student on 4/26/22.
//

import UIKit

class DetailViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        self.productnameLBL.text = name
        self.ProductPriceLBL.text = price

        // Do any additional setup after loading the view.
    }
    
    @IBOutlet weak var productnameLBL: UILabel!
    
    @IBOutlet weak var ProductPriceLBL: UILabel!
    
    var name = ""
    var price = ""
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
