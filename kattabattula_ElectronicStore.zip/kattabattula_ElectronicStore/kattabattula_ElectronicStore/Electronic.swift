//
//  Electronic.swift
//  kattabattula_ElectronicStore
//
//  Created by student on 4/26/22.
//

import Foundation

var Electronic = [["One plus 10","750$"],["iphone 12 ","900$"],["Air pods Pro","249$"],["Charging Case","40$"]]
